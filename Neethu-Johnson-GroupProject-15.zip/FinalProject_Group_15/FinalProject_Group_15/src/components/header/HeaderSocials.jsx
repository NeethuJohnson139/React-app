import React from "react";
import "./header.css";

const HeaderSocials = () => {
  return <div className=""></div>;
};

export default HeaderSocials;
